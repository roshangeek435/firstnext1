import React from "react";

const blog1 = () => {
    return <div>blog2</div>;
};

export default blog1;
