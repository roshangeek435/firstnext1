import React from "react";

const blog1 = () => {
    return <div>blog3</div>;
};

export default blog1;
